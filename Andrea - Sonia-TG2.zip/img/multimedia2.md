cafeteria-libreria.jpg: Photo by [Fernando Hernandez](https://unsplash.com/@_ferh97?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash) on [Unsplash](https://unsplash.com/photos/cafe-latte-on-table-tVugl_rtvHA?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash)

bookshop.jpg: Photo by [Pauline Loroy](https://unsplash.com/@paulinel?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash) on [Unsplash](https://unsplash.com/photos/people-inside-library-tv8PIPPY3rQ?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash)

`Foto chica joven:`

`<a href="https://www.freepik.es/foto-gratis/redactor-mujer-joven-concentrada-cabello-rosado-trabajando-casa-haciendo-notas-cuaderno_11553679.htm#page=2&query=escritora%20comic&position=7&from_view=search&track=ais&uuid=08bfeefc-68de-4f75-951d-52789501ef1b">`Imagen de karlyukav `</a>` en Freepik

foto chico gafas y tatto brazo:

`<a href="https://www.freepik.es/foto-gratis/horizontal-retrato-elegante-empresario-tatuado-mira-sonrisa-diario-contento-tener-muchos-dias-libres_9879042.htm#query=escritor%20comic&position=2&from_view=search&track=ais&uuid=8a53e47f-587e-4bb6-a8f7-5ccd9cfb74f6">`Imagen de wayhomestudio `</a>` en Freepik

foto chico camisa tejana:

Imagen de `<a href="https://www.freepik.es/foto-gratis/hombre-que-sienta-silla-que-sostiene-libro-mano-que-mira-lejos_4660209.htm#query=escritor%20comic&position=21&from_view=search&track=ais&uuid=8a53e47f-587e-4bb6-a8f7-5ccd9cfb74f6">`Freepik `</a>`

foto chica de amarillo:

`<a href="https://www.freepik.es/foto-gratis/mujer-pensativa-tratando-recordar-algo-importante_3081681.htm#query=escritora%20comic&position=24&from_view=search&track=ais&uuid=466af44d-38a1-4ec0-a3ab-76a8c10488be">`Imagen de katemangostar `</a>` en Freepik
